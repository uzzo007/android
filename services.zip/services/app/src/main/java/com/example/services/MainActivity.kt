package com.example.services

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            var data=user_data.text.toString()
            var compose= Intent(Intent.ACTION_SEND)
            compose.putExtra(Intent.EXTRA_TEXT,data)
            compose.type="text/plain"

            var sendOptions=Intent.createChooser(compose,"MSG")
            startActivity(sendOptions)
        }
    }
}