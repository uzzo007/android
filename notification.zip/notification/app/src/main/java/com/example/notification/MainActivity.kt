package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.NotificationCompat
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            val currentApp=Intent(this,MainActivity::class.java)
            val pi=PendingIntent.getActivity(this,1,currentApp,PendingIntent.FLAG_IMMUTABLE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val chan=NotificationChannel("TYITnoti","TYIT Notification",NotificationManager.IMPORTANCE_HIGH)
                chan.enableLights(true)
                chan.lightColor=Color.GREEN
                chan.enableVibration(true)

                val myNotification = NotificationCompat.Builder(this,"TYITnoti")
                myNotification.setSmallIcon(R.drawable.tea)
                myNotification.setContentTitle("TYIT")
                myNotification.setContentText("Hello, Ricky")
                myNotification.priority=NotificationManager.IMPORTANCE_HIGH
                myNotification.setAutoCancel(true)
                myNotification.setContentIntent(pi)
                myNotification.build()

                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.createNotificationChannel(chan)
                manager.notify(1, myNotification.build())
            }
        }
    }
}
