package com.example.airplanemode

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast



    class AirplaneMode:BroadcastReceiver(){
        override fun onReceive(p0: Context?, p1: Intent?) {
            var checkStatus=p1?.getBooleanExtra("state",false) ?:return

            if (checkStatus)
            {
                Toast.makeText(p0,"Airplane Mode is ON",Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(p0,"Airplane Mode is OFF",Toast.LENGTH_SHORT).show()
            }
        }
    }
