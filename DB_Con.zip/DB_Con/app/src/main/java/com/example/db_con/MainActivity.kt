package com.example.db_con

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var id:Int=0

        var my_database=MyDB(this)
        button.setOnClickListener {
            var un=username.text.toString()
            var pass=password.text.toString()
            my_database.saveUser(un,pass)
        }

        button2.setOnClickListener {
            var userD = my_database.readUsers()
            var adapt = ArrayAdapter(this,android.R.layout.simple_list_item_1,userD)

            userList.adapter = adapt
        }

        userList.setOnItemClickListener { adapterView, view, i, l ->
            var data = userList.getItemAtPosition(i).toString()[0]
            id=data.digitToInt()
            Toast.makeText(this,data.toString(),Toast.LENGTH_SHORT).show()
        }

        userList.setOnItemLongClickListener { adapterView, view, i, l ->
            var del=userList.getItemAtPosition(i).toString()[0]
            my_database.deleteUsers(del.digitToInt())
           true
       }

        button3.setOnClickListener {
            val un=username.text.toString()
            val pass=password.text.toString()
            val result = my_database.updateUsers(id,un, pass)

    }
}
}